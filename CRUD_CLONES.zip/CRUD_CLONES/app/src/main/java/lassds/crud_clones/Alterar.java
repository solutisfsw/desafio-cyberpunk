package lassds.crud_clones;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.instacart.library.truetime.TrueTime;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Alterar extends AppCompatActivity {
    private Spinner spn1,spn2;
    private List<String> idades = new ArrayList<String>();
    private List<String> adicionais = new ArrayList<String>();
    private String adicional;
    private int idade;
    private EditText nome;
    private Clone clone;
    private CloneDAO cloneHelper;
    private TextView txt,txt2;
    private static final String TAG = Alterar.class.getSimpleName();
    private Date trueTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        cloneHelper = new CloneDAO(this);
        nome = (EditText)findViewById(R.id.edtNome);
        spn1 = (Spinner) findViewById(R.id.spinner1);
        spn2 = (Spinner) findViewById(R.id.spinner2);
        txt = (TextView) findViewById(R.id.textView5);

        txt2 = (TextView) findViewById(R.id.textViewDt);
        if(verificaConexao()) {
            pegarDataInternet();
        }

        idades.add("11");
        idades.add("12");
        idades.add("13");
        idades.add("14");
        idades.add("15");
        idades.add("16");
        idades.add("17");
        idades.add("18");
        idades.add("19");

        adicionais.add("Braço Mecânico");
        adicionais.add("Esqueleto Reforçado");
        adicionais.add("Sentidos Aguçados");
        adicionais.add("Pele Adaptativa");
        adicionais.add("Raio Laser");
    }

    public void buscar(View view) {
        if(nome.getText().toString().equals("")) {
            nome.setError("Campo em branco!");
        }else if (!verificarBanco()){
            nome.setError("Clone não existe!");
        }else {
            txt.setText(clone.getDataCriacao().toString());
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, idades);
            ArrayAdapter<String> spinnerArrayAdapter = arrayAdapter;
            spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
            spn1.setAdapter(spinnerArrayAdapter);
            spn1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                @Override
                public void onItemSelected(AdapterView<?> parent, View v, int posicao, long id) {
                    idade = Integer.parseInt(parent.getItemAtPosition(posicao).toString());
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, adicionais);
            ArrayAdapter<String> spinnerArrayAdapter2 = arrayAdapter2;
            spinnerArrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
            spn2.setAdapter(spinnerArrayAdapter2);
            spn2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                @Override
                public void onItemSelected(AdapterView<?> parent, View v, int posicao, long id) {
                    adicional = parent.getItemAtPosition(posicao).toString();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            for (int i = 0; i < spn1.getAdapter().getCount(); i++) {
                if (spn1.getAdapter().getItem(i).toString().contains(String.valueOf(clone.getIdade()))) {
                    spn1.setSelection(i);
                }
            }

            for (int i = 0; i < spn2.getAdapter().getCount(); i++) {
                if (spn2.getAdapter().getItem(i).toString().contains(clone.getAdicional().toString())) {
                    spn2.setSelection(i);
                }
            }
        }

    }

    public boolean verificarBanco (){
        clone = cloneHelper.getCloneByNome(nome.getText().toString());
        if(clone == null){
            return false;
        }
        return true;
    }

    public void alterar(View view){
        if(nome.getText().toString().equals("")) {
            nome.setError("Campo em branco!");
        }else if (!verificarBanco()){
            nome.setError("Clone não existe!");
        }else {

            try {
                clone.setNome(nome.getText().toString());
                clone.setIdade(idade);
                clone.setAdicional(adicional);
                cloneHelper.alterarClone(clone);
                Toast.makeText(this, "Alterado com sucesso!", Toast.LENGTH_SHORT).show();
                nome.setText("");
                txt.setText("");
                spn1.setAdapter(null);
                spn2.setAdapter(null);
            } catch (Exception e) {
                e.getStackTrace();
            }
        }

    }

    public void cancelar(View v) {
        Intent i = new Intent(this, Menu.class);
        startActivity(i);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent i = new Intent(this, Menu.class);
                startActivity(i);
                finish();
                break;
            default:break;
        }
        return true;
    }

    @Override
    public void onBackPressed(){
        Intent i = new Intent(this, Menu.class);
        startActivity(i);
        finish();
        return;
    }

    public void pegarDataInternet(){
        do{
            new InitTrueTimeAsyncTask().execute();
        }while(!TrueTime.isInitialized());
        updateCurrentTime();
        final Handler handler=new Handler();

        final Runnable updateTask=new Runnable() {
            @Override
            public void run() {
                updateCurrentTime();
                handler.postDelayed(this,1000);
            }
        };

        handler.postDelayed(updateTask,1000);

    }

    public void updateCurrentTime(){
        trueTime = TrueTime.now();
        txt2.setText(formatDate(trueTime, "dd-MM-yyyy - HH:mm:ss", TimeZone.getTimeZone("GMT-03:00")));
    }

    private class InitTrueTimeAsyncTask
            extends AsyncTask<Void, Void, Void> {

        protected Void doInBackground(Void... params) {
            try {
                TrueTime.build()
                        .withNtpHost("time.google.com")
                        .withLoggingEnabled(false)
                        .withConnectionTimeout(3_1428)
                        .initialize();
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(TAG, "Exception when trying to get TrueTime", e);
            }
            return null;
        }
    }


    private String formatDate(Date date, String pattern, TimeZone timeZone) {
        DateFormat format = new SimpleDateFormat(pattern, Locale.ENGLISH);
        format.setTimeZone(timeZone);
        return format.format(date);
    }

    public  boolean verificaConexao() {
        boolean conectado;
        ConnectivityManager conectivtyManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (conectivtyManager.getActiveNetworkInfo() != null
                && conectivtyManager.getActiveNetworkInfo().isAvailable()
                && conectivtyManager.getActiveNetworkInfo().isConnected()) {
            conectado = true;
        } else {
            conectado = false;
        }
        return conectado;
    }
}
