package lassds.crud_clones;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by L.A.S.S on 25/02/2018.
 */

public class CloneDAO extends SQLiteOpenHelper {

    private static final int VERSAO = 1;
    private static final String TABELA = "clone";
    private static final String DATABASE = "AppClone";

    public CloneDAO(Context context) {
        super(context, DATABASE, null, VERSAO);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String ddl = "CREATE TABLE IF NOT EXISTS "+ TABELA +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "nome TEXT, " +
                "idade INTEGER , " +
                "dataCriacao TEXT, " +
                "adicional TEXT);";
        db.execSQL(ddl);
    }

    public void inserirClone(Clone clone){
        ContentValues values = new ContentValues();
        values.put("nome", clone.getNome());
        values.put("idade", clone.getIdade());
        values.put("dataCriacao", clone.getDataCriacao());
        values.put("adicional", clone.getAdicional());
        getWritableDatabase().insert(TABELA, null, values);
    }
    public void apagarclone(Clone clone){
        String args[] = {Integer.toString(clone.getId())};
        getWritableDatabase().delete(TABELA, "id=?", args);
    }

    public void alterarClone(Clone clone){
        ContentValues values = new ContentValues();
        values.put("nome", clone.getNome());
        values.put("idade", clone.getIdade());
        values.put("adicional", clone.getAdicional());
        String args[] = {Integer.toString(clone.getId())};
        getWritableDatabase().update(TABELA, values, "id=?", args);
    }

    public List<Clone> getListaClone(){
        List<Clone> lista = new ArrayList<Clone>();
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM " + TABELA + ";", null);
        while (cursor.moveToNext()){
            Clone clone = new Clone();
            clone.setId(cursor.getInt(cursor.getColumnIndex("id")));
            clone.setNome(cursor.getString(cursor.getColumnIndex("nome")));
            clone.setIdade(cursor.getInt(cursor.getColumnIndex("idade")));
            clone.setDataCriacao(cursor.getString(cursor.getColumnIndex("dataCriacao")));
            clone.setAdicional(cursor.getString(cursor.getColumnIndex("adicional")));
            lista.add(clone);
        }
        cursor.close();
        return lista;
    }

    public Clone getCloneByNome(String nome){
        String querySql = "SELECT id,nome,idade,dataCriacao,adicional FROM clone WHERE nome = ?";
        Cursor cursor = getReadableDatabase().rawQuery(querySql,new String[]{nome});
        cursor.moveToFirst();
        Clone clone = new Clone();
        if(cursor.getCount()<1) {
            clone = null;
        }else {
            clone.setId(cursor.getInt(cursor.getColumnIndex("id")));
            clone.setNome(cursor.getString(cursor.getColumnIndex("nome")));
            clone.setIdade(cursor.getInt(cursor.getColumnIndex("idade")));
            clone.setDataCriacao(cursor.getString(cursor.getColumnIndex("dataCriacao")));
            clone.setAdicional(cursor.getString(cursor.getColumnIndex("adicional")));
        }
        cursor.close();
        return clone;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
