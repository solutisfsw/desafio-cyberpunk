package lassds.crud_clones;


import static android.text.TextUtils.concat;

/**
 * Created by L.A.S.S on 25/02/2018.
 */

public class Clone {
    private int id;
    private String nome;
    private int idade;
    private String dataCriacao;
    private String adicional;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(String dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public String getAdicional() {
        return adicional;
    }

    public void setAdicional(String adicional) {
        this.adicional = adicional;
    }

    @Override
    public String toString() {
        return String.valueOf(concat("Id: "+id+"\nNome: "+nome+"\nIdade: "+idade+"\nAdicional: "+adicional+"\nData de Criação: " + dataCriacao));
    }
}