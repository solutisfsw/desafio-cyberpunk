package lassds.crud_clones;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.instacart.library.truetime.TrueTime;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Deletar extends AppCompatActivity {
    private Spinner spn1,spn2;
    private List<String> idades = new ArrayList<String>();
    private List<String> adicionais = new ArrayList<String>();
    private EditText nome;
    private CloneDAO cloneHelper;
    private Clone clone;
    private TextView txt,txt2;
    private static final String TAG = Deletar.class.getSimpleName();
    private Date trueTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deletar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        cloneHelper = new CloneDAO(this);
        nome = (EditText)findViewById(R.id.edtNome);
        spn1 = (Spinner) findViewById(R.id.spinner1);
        spn2 = (Spinner) findViewById(R.id.spinner2);
        txt = (TextView) findViewById(R.id.textView5);
        txt2 = (TextView) findViewById(R.id.textViewDt);
        if(verificaConexao()) {
            pegarDataInternet();
        }
    }

    public void buscar(View view) {
        if(nome.getText().toString().equals("")) {
            nome.setError("Campo em branco!");
        }else if (!verificarBanco()){
            nome.setError("Clone não existe!");
        }else {

            idades.add(String.valueOf(clone.getIdade()));
            adicionais.add(clone.getAdicional().toString());
            txt.setText(clone.getDataCriacao().toString());

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, idades);
            ArrayAdapter<String> spinnerArrayAdapter = arrayAdapter;
            spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
            spn1.setAdapter(spinnerArrayAdapter);

            ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, adicionais);
            ArrayAdapter<String> spinnerArrayAdapter2 = arrayAdapter2;
            spinnerArrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
            spn2.setAdapter(spinnerArrayAdapter2);
            spn1.setEnabled(false);
            spn2.setEnabled(false);
        }
    }

    public boolean verificarBanco (){
        clone = cloneHelper.getCloneByNome(nome.getText().toString());
        if(clone == null){
            return false;
        }
        return true;
    }

    public void deletar(View view){
        if(nome.getText().toString().equals("")) {
            nome.setError("Campo em branco!");
        }else if (!verificarBanco()){
            nome.setError("Clone não existe!");
        }else {
            try {
                cloneHelper.apagarclone(clone);
                Toast.makeText(this, "Deletado com sucesso!", Toast.LENGTH_SHORT).show();
                nome.setText("");
                txt.setText("");
                spn1.setAdapter(null);
                spn2.setAdapter(null);
            } catch (Exception e) {
                e.getStackTrace();
            }
        }
    }

    public void cancelar(View v) {
        Intent i = new Intent(this, Menu.class);
        startActivity(i);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent i = new Intent(this, Menu.class);
                startActivity(i);
                finish();
                break;
            default:break;
        }
        return true;
    }

    @Override
    public void onBackPressed(){
        Intent i = new Intent(this, Menu.class);
        startActivity(i);
        finish();
        return;
    }

    public void pegarDataInternet(){
        do{
            new InitTrueTimeAsyncTask().execute();
        }while(!TrueTime.isInitialized());
        updateCurrentTime();
        final Handler handler=new Handler();

        final Runnable updateTask=new Runnable() {
            @Override
            public void run() {
                updateCurrentTime();
                handler.postDelayed(this,1000);
            }
        };

        handler.postDelayed(updateTask,1000);

    }

    public void updateCurrentTime(){
        trueTime = TrueTime.now();
        txt2.setText(formatDate(trueTime, "dd-MM-yyyy - HH:mm:ss", TimeZone.getTimeZone("GMT-03:00")));
    }

    private class InitTrueTimeAsyncTask
            extends AsyncTask<Void, Void, Void> {

        protected Void doInBackground(Void... params) {
            try {
                TrueTime.build()
                        .withNtpHost("time.google.com")
                        .withLoggingEnabled(false)
                        .withConnectionTimeout(3_1428)
                        .initialize();
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(TAG, "Exception when trying to get TrueTime", e);
            }
            return null;
        }
    }


    private String formatDate(Date date, String pattern, TimeZone timeZone) {
        DateFormat format = new SimpleDateFormat(pattern, Locale.ENGLISH);
        format.setTimeZone(timeZone);
        return format.format(date);
    }

    public  boolean verificaConexao() {
        boolean conectado;
        ConnectivityManager conectivtyManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (conectivtyManager.getActiveNetworkInfo() != null
                && conectivtyManager.getActiveNetworkInfo().isAvailable()
                && conectivtyManager.getActiveNetworkInfo().isConnected()) {
            conectado = true;
        } else {
            conectado = false;
        }
        return conectado;
    }
}
