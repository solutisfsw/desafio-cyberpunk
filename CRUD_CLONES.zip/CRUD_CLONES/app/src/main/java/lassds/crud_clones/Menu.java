package lassds.crud_clones;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.instacart.library.truetime.TrueTime;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


public class Menu extends AppCompatActivity {
    private TextView txt;
    private static final String TAG = Menu.class.getSimpleName();
    private Date trueTime;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        txt = (TextView) findViewById(R.id.textViewDt);
        if(verificaConexao()) {
            pegarDataInternet();
        }
    }

    public void onClick(View v){
        if(v.getId() == R.id.btCadastrar) {
            Intent i = new Intent(this, Cadastrar.class);
            startActivity(i);
            finish();
        }else if(v.getId() == R.id.btDeletar){
            Intent i = new Intent(this, Deletar.class);
            startActivity(i);
            finish();
        }else if(v.getId() == R.id.btAlterar) {
            Intent i = new Intent(this, Alterar.class);
            startActivity(i);
            finish();
        }else{
            Intent i = new Intent(this, Listar.class);
            startActivity(i);
            finish();
        }
    }

    public void pegarDataInternet(){
        do{
            new InitTrueTimeAsyncTask().execute();
        }while(!TrueTime.isInitialized());
        updateCurrentTime();
        final Handler handler=new Handler();

        final Runnable updateTask=new Runnable() {
            @Override
            public void run() {
                updateCurrentTime();
                handler.postDelayed(this,1000);
            }
        };

        handler.postDelayed(updateTask,1000);

    }

    public void updateCurrentTime(){
        trueTime = TrueTime.now();
        txt.setText(formatDate(trueTime, "dd-MM-yyyy - HH:mm:ss", TimeZone.getTimeZone("GMT-03:00")));
    }

    private class InitTrueTimeAsyncTask
            extends AsyncTask<Void, Void, Void> {

        protected Void doInBackground(Void... params) {
            try {
                TrueTime.build()
                        .withNtpHost("time.google.com")
                        .withLoggingEnabled(false)
                        .withConnectionTimeout(3_1428)
                        .initialize();
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(TAG, "Exception when trying to get TrueTime", e);
            }
            return null;
        }
    }


    private String formatDate(Date date, String pattern, TimeZone timeZone) {
        DateFormat format = new SimpleDateFormat(pattern, Locale.ENGLISH);
        format.setTimeZone(timeZone);
        return format.format(date);
    }

    public  boolean verificaConexao() {
        boolean conectado;
        ConnectivityManager conectivtyManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (conectivtyManager.getActiveNetworkInfo() != null
                && conectivtyManager.getActiveNetworkInfo().isAvailable()
                && conectivtyManager.getActiveNetworkInfo().isConnected()) {
            conectado = true;
        } else {
            conectado = false;
        }
        return conectado;
    }


}
