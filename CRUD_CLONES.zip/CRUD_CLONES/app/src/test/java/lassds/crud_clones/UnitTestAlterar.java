package lassds.crud_clones;

import org.junit.Test;

/**
 * Created by L.A.S.S on 02/03/2018.
 */

public class UnitTestAlterar {
    @Test
    public void alterar() throws Exception {
        String nome = "AAA12345";

        if (nome.equals("")) {
            System.out.println("Campo em branco!");
        }else if(!verificaBanco(nome)){
            System.out.println("Clone não existe!");
        } else {
            System.out.println("Alterado com sucesso!");
        }
    }

    public boolean verificaBanco(String nome){
        String nome2 = "AAA1234";

        if(nome == nome2){
            return true;
        }
        return false;
    }
}
