/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cyberpunk;

import java.util.ArrayList;


/**
 *
 * @author JuanCaio
 * 
 */

public class Clones {
    private String nome;
    private int idade;
    private String data;
    private int add;
 
    
    public void gerandoNome (){
        int random;
		boolean v = false;
		for(int i = 0; i<7; i++) {
			v = false;
			do {
				random = (int) (Math.random() * 122);
				if (random >= 48 && random <= 57)
					v = true;
				else if (random >= 97 && random <= 122)
					v = true;
				else if (random >= 65 && random <= 90)
					v = true;
			} while (!v);
			System.out.print((char) random);
		}
    }
    
    public void adicionais(){
        ArrayList<String> adicional = new ArrayList<String> ();
        adicional.add("braço mecânico");
        adicional.add("esqueleto reforçado");
        adicional.add("sentidos aguçados");
        adicional.add("pele adaptativa");
        adicional.add("raio laser");
        adicional.add ("Sem adicional");
        
        System.out.println("Adicional: " + adicional.get(add)); 
    }
    
    public int gerandoIdade (){
        if (idade < 10){
            System.out.println("A idade deve ser entre 10 e 20");
        }else if (idade > 20){
            System.out.println("A idade deve ser entre 10 e 20");
        }else{
            System.out.println("Idade: " + idade);
        }
        return idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    
    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getAdd() {
        return add;
    }

    public void setAdd(int add) {
        this.add = add;
    }

    
}
