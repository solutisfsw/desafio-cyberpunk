/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cyberpunk;

import java.util.Scanner;

/**
 *
 * @author JuanCaio
 */
public class Cadastro {
    public static void main(String[] args) {
        int entIdade;
        String entData;
        int entAdicionais;
        
        Scanner sc = new Scanner(System.in);
        
        Clones androide = new Clones ();
        
        //informação de idade 
        System.out.println("Informe a idade");
        entIdade = sc.nextInt();
        androide.setIdade(entIdade);
        androide.gerandoIdade();
        
        //informação de data
        System.out.println("Informe a data");
        entData = sc.next();
        androide.setData(entData);
        
        
        //informação de adicional 
        System.out.println("Informe o código dos adicionais: "
                + " - 0 braço mecânico"
                + " - 1 esqueleto reforçado"
                + " - 2 sentidos aguçados"
                + " - 3 pele adaptativa"
                + " - 4 raio laser"
                + " - 5 sem adicional");
        
        entAdicionais = sc.nextInt();
        if (entAdicionais > 5){
            System.out.println("Os números válidos são de 0 a 5");
        }else{
            androide.setAdd(entAdicionais);
           
        }
        
        //Informações do Clone Cadastrado
        if(entIdade<10 || entIdade>20 || entAdicionais >5 ){
            System.out.println("Cadastro Invalido revise os itens idade e adicionais");
        }else{
                System.out.println("**************************************************************************************************");
                System.out.println("Nome: ");
                androide.gerandoNome();
                System.out.println("                                                                                                  ");
                androide.gerandoIdade();
                System.out.println("Data de Cadastro: "+ androide.getData());
                androide.adicionais();
        }    
    }
    
}
